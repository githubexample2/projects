package internalinputinloop;
import java.util.*;

public class TravellerMain {

	public static void main(String[] args) {
		String planetName;
		String speciesType; 
		int energy; 

		Scanner input = new Scanner(System.in);
		
		System.out.println("What is your Planets name?");
		planetName = input.nextLine();
		System.out.println("What is your species type?");
		speciesType = input.nextLine();
		System.out.println("What is the energy level (100-700)");
		energy = input.nextInt();
		
		PlanetVibe obj1 = new PlanetVibe(planetName, speciesType, energy);
		obj1.TestGreeting();
		obj1.SpeciesType();
		obj1.Power();
	}

}
