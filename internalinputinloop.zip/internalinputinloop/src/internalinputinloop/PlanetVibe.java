package internalinputinloop;

public class PlanetVibe {
	
	String planetName;
	String speciesType; 
	int energy; 
	
	
	
	public PlanetVibe(String planetName, String speciesType, int energy) {
		this.planetName = planetName;
		this.speciesType = speciesType;
		this.energy = energy; 
	} 

	void MarsGreeting() {
		System.out.println("Welcome to Mars");
	}
	
	void EarthGreeting() {
		System.out.println("Welcome to Earth");
	}
	
	void MercuryGreeting() {
		System.out.println("Welcome to Mercury");
	}
	
	
	
	
	void GreetingOne() {
		switch (planetName) {
		  case "Mars":
			  System.out.println("Welcome to Mars");
		    break;
		  case "Earth":
			  System.out.println("Welcome to Earth");
		    break;
		  case "Jupiter":
			  System.out.println("Welcome to Jupiter");
		    break;
		  case "Neptune":
			  System.out.println("Welcome to Neptune");
		    break;
		  case "Saturn":
			  System.out.println("Welcome to Saturn");
		    break;
		  case "Venus":
			  System.out.println("Welcome to Venus");
		    break;
		  case "Uranus":
			  System.out.println("Welcome to Uranus");
		    break;
		  case "Mercury":
			  System.out.println("Welcome to Mercury");
		}
		
	}
	
	void GreetingTwo() {
		System.out.println("Welcome to " + planetName);
	}
	
	void TestGreeting() {
		if(planetName == "Earth" || planetName == "Mars" || planetName == "Jupiter" || planetName == "Neptune" || planetName == "Saturn" || planetName == "Venus" || planetName == "Uranus" || planetName == "Mercury") {
			System.out.println("Welcome to " + planetName);
		}
		else {
			System.out.println("Congratulations, you discovered another planet, Nasa wants you to meet you!");
		}
	}
	
	void SpeciesType() {
		System.out.println("My species type is " + speciesType);
	}
	
	void Power() {
		switch (planetName) {
		  case "100":
			  System.out.println("You can enjoy ambrosia!");
			  for(int i = 0; i<2; i++) {
				  System.out.println("Onomnomnom! Yummy");
			  }
		    break;
		  case "200":
			  System.out.println("You can enjoy gelato");
			  for(int i = 0; i<3; i++) {
				  System.out.println("Onomnomnom! Yummy");
			  }
		    break;
		  case "300":
			  System.out.println("You can enjoy baklava");
			  for(int i = 0; i<4; i++) {
				  System.out.println("Onomnomnom! Delicious!");
			  }
		    break;
		  case "400":
			  System.out.println("You can enjoy kataifi");
			  for(int i = 0; i<5; i++) {
				  System.out.println("Onomnomnom! Mouth-watering");
			  }
		    break;
		  case "500":
			  System.out.println("You can enjoy red bean buns");
			  for(int i = 0; i<6; i++) {
				  System.out.println("Onomnomnom! Best-dessert-ever!!");
			  }
		    break;
		  case "600":
			  System.out.println("You can enjoy crêpes");
			  for(int i = 0; i<7; i++) {
				  System.out.println("Onomnomnom! MIND BLOWING, FANTASTIC, UNBELIEVABLE");
			  }
		    break;
		  case "700":
			  System.out.println("You can enjoy ras malai");
			  for(int i = 0; i<8; i++) {
				  System.out.println("Onomnomnom! SPEECHLESS");
			  }
		    break;
		  case "800":
			  System.out.println("You can enjoy mochi");
			  for(int i = 0; i<5; i++) {
				  System.out.println("Onomnomnom! I think I tasted the nectar of the heavens!");
			  }
		 default: 
			 System.out.println("You can enjoy a wheat grass shot!");
		}
		
	}

	
	

}
